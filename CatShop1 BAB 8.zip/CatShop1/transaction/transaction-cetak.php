<?php

include('../koneksi.php');
require_once("../dompdf/autoload.inc.php");

use Dompdf\Dompdf;

$dompdf = new Dompdf();
$query = mysqli_query($koneksi, "SELECT * FROM tb_transaction");

$html = '
<!DOCTYPE html>
<html>
<head>
    <title>Laporan Transaksi CatShop</title>
    <style>
        body { font-family: sans-serif; font-size: 12px; }
        h3 { text-align: center; margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #333333; padding: 8px; text-align: left; }
        th { background-color: #c2c2d7; }
    </style>
</head>
<body>
    <h3>Laporan Data Transaksi - CatShop</h3>
    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Tanggal</th>
                <th>Nama</th>
                <th>Kategori</th>
                <th>Harga</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>';

$no = 1;
while ($row = mysqli_fetch_array($query)) {
    $html .= "
            <tr>
                <td>" . $no++ . "</td>
                <td>" . $row['tanggal'] . "</td>
                <td>" . $row['nama'] . "</td>
                <td>" . $row['jenis'] . "</td>
                <td>" . $row['harga'] . "</td>
                <td>" . $row['status'] . "</td>
            </tr>";
}

$html .= '
        </tbody>
    </table>
</body>
</html>';

$dompdf->loadHtml($html);

$dompdf->setPaper('A4', 'portrait');

$dompdf->render();

$dompdf->stream('laporan_transaksi.pdf', array("Attachment" => 0));
?>